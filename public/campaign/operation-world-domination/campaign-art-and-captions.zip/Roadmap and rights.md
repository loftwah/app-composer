# Roadmap and publication rights

The undersea briefing is fiction. Live inserts show public App Composer or Media Studio journeys at capture time on 24 November 2026 AEDT. The film treats independently owned first-app acceptance, long-running bounded autonomy, community remix, enterprise federation and the independent self-rebuild as roadmap work. One trillion tokens is Quill’s target. It is not a current usage number, capacity promise, spend goal or reason to run a model unnecessarily.

| Operation | Factual source |
| --- | --- |
| Frickin’ Easy | [Onboarding #1126](https://github.com/loftwah/app-composer/issues/1126), [independent newcomer proof #425](https://github.com/loftwah/app-composer/issues/425), [current Learn](https://composer.loftwah.com/learn) |
| Mini-Me | [EmDash command centre #658](https://github.com/loftwah/app-composer/issues/658), [scoped agent coordination #597](https://github.com/loftwah/app-composer/issues/597), [Discord #420](https://github.com/loftwah/app-composer/issues/420), [longer autonomy proof #1121](https://github.com/loftwah/app-composer/issues/1121), [current agent guide](https://composer.loftwah.com/agent) |
| LEGO Empire | [Reusable capabilities #476](https://github.com/loftwah/app-composer/issues/476), [selective reuse #997](https://github.com/loftwah/app-composer/issues/997), [current connected-apps demo](https://composer.loftwah.com/demo/connected-apps) |
| Hollywood | [Creative production benchmark #1019](https://github.com/loftwah/app-composer/issues/1019), [Game Studio #659](https://github.com/loftwah/app-composer/issues/659), [music release #1051](https://github.com/loftwah/app-composer/issues/1051), [current Media Studio](https://media.loftwah.com/gallery) |
| Unlimited Tokens | [Workers AI value #936](https://github.com/loftwah/app-composer/issues/936), [cited runtime answer recipe #991](https://github.com/loftwah/app-composer/issues/991), [Cloudflare Workers AI pricing](https://developers.cloudflare.com/workers-ai/platform/pricing/) |
| Self-Replication | [Share #477](https://github.com/loftwah/app-composer/issues/477), [community creation #1096](https://github.com/loftwah/app-composer/issues/1096), [current Share](https://composer.loftwah.com/share?view=films) |
| Sharks with Frickin’ Benchmarks | [Benchmark acceptance #935](https://github.com/loftwah/app-composer/issues/935), [current Benchmarks](https://composer.loftwah.com/benchmarks) |
| Corporate Takeover | [Enterprise roles and access #660](https://github.com/loftwah/app-composer/issues/660), [current sequence and pilot limits](https://github.com/loftwah/app-composer/blob/main/docs/roadmap.md) |
| Ouroboros | [Independent self-rebuild #931](https://github.com/loftwah/app-composer/issues/931), [product vision](https://github.com/loftwah/app-composer/blob/main/PRODUCT.md) |

## Rights inventory

- The screenplay and all score motifs, sound design, fictional characters, sets, prop designs and advertising treatments were created for this film. No commercial music, actor likeness, cloned performer or movie footage was used.
- The original stills were generated with Codex ImageGen. Analog motion inserts were newly generated with Veo 3.1 Lite in the existing ElevenCreative Starter workspace. Character motion used original uploaded stills in Media Studio with Hailuo 2.3 Standard through the existing fal.ai connection. Source generations were silent. The production remixed only its own footage and recorded public product screens.
- Spoken performances use two local Kokoro-82M v1.0 voice blends under the model’s Apache 2.0 release. The distinct synthetic identities were created for this script. No third-party voice cloning or performer imitation was requested. [Model and license](https://huggingface.co/hexgrad/Kokoro-82M).
- The product inserts are screen recordings from the commissioner's public App Composer and Media Studio properties. Product and provider names are used to identify their roles. LEGO appears only in the commissioned chapter title and no branded toy design is depicted.
- The public film and campaign art are cleared for this App Composer release. Any further redistribution or derivative reuse is subject to the relevant rights and publication terms.
