# Replay the Keep a Copy edit

The source archive contains both editable Studio CompositionV1 files, the exact source manifest, preparation and comparison scripts, captions and the observed revision proof. Download source media separately and keep the preceding master.

Use Python 3.12 with Pillow 13, FFmpeg with libx264 and AAC, and macOS stock Arial fonts for the supplied end-card script. Create a fresh directory layout and pass its root to `python inputs/prepare.py --gits /your/path`.

| Published source | Place it under that root |
| --- | --- |
| [Change the Default](https://fm.loftwah.com/media/who-keeps-the-map/change-the-default-rhythm-1becbd4f.mp4) | `just-stuff/change-the-default/Change-The-Default-Rhythm-Cut.mp4` |
| [Encore Cut](https://fm.loftwah.com/media/who-keeps-the-map/who-gets-the-change-encore-12d59070.mp4) | `just-stuff/who-gets-the-change/who-gets-the-change-encore-cut.mp4` |
| [Album cover](https://fm.loftwah.com/media/who-keeps-the-map/cover.jpg) | `loftwahfm/music/who-keeps-the-map/cover.jpg` |
| [Rhythm Cut captions](https://fm.loftwah.com/media/who-keeps-the-map/change-the-default-rhythm-1becbd4f-en.vtt) | `just-stuff/change-the-default/publication/change-the-default-rhythm-1becbd4f-en.vtt` |

Compare the media SHA-256 values with `inputs/origin.json`. Run the [Studio editor bridge at b96f955](https://github.com/loftwah/composer-media-studio/blob/b96f955/docs/editor-bridge-experiment.md). Give each revision a fresh output directory and use one cache for both.

```sh
python /path/to/editor-bridge-probe.py render --composition inputs/composition-v1.json --assets inputs/assets.json --output v1 --cache cache
python /path/to/editor-bridge-probe.py render --composition inputs/composition-v2.json --assets inputs/assets.json --output v2 --cache cache
python inputs/prove-revision.py
```

The first and revised landscape timeline each run 35 seconds. The supplied proof compares decoded frames and audio on the original Mac run. Encoder versions and fonts can change export bytes.
