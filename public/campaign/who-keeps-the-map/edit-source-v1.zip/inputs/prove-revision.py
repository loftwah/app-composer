#!/usr/bin/env python3
"""Reopen both Studio bridge masters and verify the edit's exact scope."""
from argparse import ArgumentParser
from hashlib import file_digest
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from io import BytesIO
from PIL import Image
import json
import subprocess

HERE = Path(__file__).resolve().parent
OUT = HERE.parent


def sha(path):
    with path.open("rb") as file:
        return file_digest(file, "sha256").hexdigest()


def ffmpeg(*arguments):
    return subprocess.run(
        ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin",
         "-n", "-threads", "2", *map(str, arguments)],
        check=True, stdout=subprocess.PIPE,
    ).stdout


def main():
    parser = ArgumentParser()
    parser.add_argument("--bridge", type=Path, default=Path.home() / "gits/composer-media-studio/scripts/editor-bridge-probe.py")
    args = parser.parse_args()
    spec = spec_from_file_location("studio_editor_bridge", args.bridge)
    bridge = module_from_spec(spec)
    spec.loader.exec_module(bridge)
    bridge.doctor()

    v1, v2 = [OUT / f"v{version}/landscape/master.mp4" for version in (1, 2)]
    before, after = bridge.video_frame_hashes(v1), bridge.video_frame_hashes(v2)
    sound_before, sound_after = bridge.audio_hash(v1), bridge.audio_hash(v2)
    lo, hi = 387, 537
    changed = [i for i, frames in enumerate(zip(before, after)) if frames[0] != frames[1]]
    assert len(before) == len(after) == 1050
    assert changed == list(range(lo, hi))
    assert sound_before == sound_after
    first_receipt = json.loads((OUT / "v1/receipt.json").read_text())
    second_receipt = json.loads((OUT / "v2/receipt.json").read_text())
    assert sha(v1) == first_receipt["outputs"]["landscape"]["master"]["sha256"]
    assert sha(v2) == second_receipt["outputs"]["landscape"]["master"]["sha256"]
    hits = [shot["cache_hit"] for shot in second_receipt["outputs"]["landscape"]["shots"]]
    assert hits == [True, True, False, True, True, True]

    playhead = "16.700"
    for master, name in [(v1, "edit-before.webp"), (v2, "edit-after.webp")]:
        frame = ffmpeg("-ss", playhead, "-i", master, "-frames:v", 1, "-vf", "scale=800:-2",
                        "-c:v", "png", "-f", "image2pipe", "-")
        Image.open(BytesIO(frame)).save(OUT / name, "webp", quality=86, method=6)

    proof = {
        "format": "studio-editor-bridge-owned-media-revision/v1",
        "title": "Keep a Copy",
        "composition_id": "loftwahfm-keep-a-copy",
        "first_output_sha256": sha(v1),
        "revised_output_sha256": sha(v2),
        "total_ms": 35000,
        "fps": 30,
        "total_decoded_frames_per_master": 1050,
        "changed_shot": 3,
        "changed_range_ms": [12900, 17900],
        "changed_frame_range_zero_based_exclusive_end": [lo, hi],
        "changed_decoded_frames": len(changed),
        "unchanged_decoded_frames_exact_match": len(before) - len(changed),
        "decoded_audio_sha256_both_masters": sound_after.split("=", 1)[1],
        "earlier_master_sha256_still_matches_original_receipt": True,
        "revision_cache_hits": hits,
        "comparison_playhead_ms": 16700,
        "comparison_frame_zero_based": 501,
        "before": "Encore at 02:57.500 shows the red car in motion.",
        "after": "Encore 02:48.700 frame shows the release paperwork passing between two people.",
        "creative_reason": "The red car was a strong movement beat, but the handoff makes the lyric about keeping the keys visible as a useful original changing hands.",
        "bridge_sha256": sha(args.bridge),
        "incremental_provider_charges": 0,
        "provider_calls": 0,
    }
    (OUT / "revision-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
    print(json.dumps(proof, indent=2))


if __name__ == "__main__":
    main()
