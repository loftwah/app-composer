#!/usr/bin/env python3
"""Prepare the owned-media cut and its one-shot revision for Studio's editor bridge."""
from argparse import ArgumentParser
from hashlib import file_digest
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageOps
import json
import re
import subprocess

HERE = Path(__file__).resolve().parent
DEFAULT_GITS = Path.home() / "gits"
CHANGE_HASH = "1becbd4fcf064de8968175193f21a98dbab3ed9c7db752abf9dc5f33b329873c"
ENCORE_HASH = "12d590707bd5b6f7a714b24fef80dffc5059a6b05bed7ce8c7bcb5c5e400f061"
TOTAL = 35_000
AUDIO_IN = 51_000
FONT_DIR = Path("/System/Library/Fonts/Supplemental")
SHOT_SPECS = [
    ("keys", "rhythm", 51_000, 4600),
    ("first_hook", "rhythm", 55_600, 8300),
    ("pursuit", "encore", 173_700, 5000),
    ("handoff", "encore", 164_900, 5000),
    ("keep_the_keys", "rhythm", 68_900, 5500),
    ("raise_the_map", "encore", 184_700, 6400),
    ("release_sleeve", "card", 0, 5200),
]
CUTS = ["keys", "first_hook", "pursuit", "keep_the_keys", "raise_the_map", "release_sleeve"]


def sha(path):
    with path.open("rb") as file:
        return file_digest(file, "sha256").hexdigest()


def dump(filename, data):
    (HERE / filename).write_text(json.dumps(data, indent=2) + "\n")


def ffmpeg(*arguments):
    subprocess.run(
        ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin", "-n",
         "-threads", "2", "-filter_threads", "1", *map(str, arguments)],
        check=True,
    )


def build_card(cover, output):
    # Dark plum from the sleeve lettering, light paper and a warm yellow rule.
    image = Image.new("RGB", (1280, 720), "#1b1028")
    draw = ImageDraw.Draw(image)
    cream = "#fff2d6"
    yellow = "#ffd448"
    grey = "#decce8"
    label = ImageFont.truetype(FONT_DIR / "Arial Bold.ttf", 32)
    punch = ImageFont.truetype(FONT_DIR / "Arial Black.ttf", 94)
    body = ImageFont.truetype(FONT_DIR / "Arial.ttf", 35)
    action = ImageFont.truetype(FONT_DIR / "Arial Bold.ttf", 45)

    cover_image = ImageOps.fit(Image.open(cover).convert("RGB"), (504, 504),
                              method=Image.Resampling.LANCZOS)
    draw.rectangle((67, 91, 589, 613), fill="#352143")
    image.paste(cover_image, (74, 98))
    draw.rectangle((74, 98, 577, 601), outline="#f1d4bb", width=1)
    draw.rectangle((631, 108, 706, 115), fill=yellow)
    draw.text((631, 137), "LOFTWAHFM", font=label, fill=yellow, anchor="lt")
    draw.text((625, 201), "KEEP A", font=punch, fill=cream, anchor="lt")
    draw.text((625, 291), "COPY.", font=punch, fill=cream, anchor="lt")
    draw.text((632, 400), "19 tracks, two films", font=body, fill=grey, anchor="lt")
    draw.text((632, 447), "and an eight-page comic.", font=body, fill=grey, anchor="lt")
    draw.text((630, 521), "fm.loftwah.com", font=action, fill=yellow, anchor="lt")
    draw.line((631, 578, 1185, 578), fill="#65416d", width=2)
    draw.text((631, 596), "Music and films by Loftwah", font=label, fill=cream, anchor="lt")
    image.save(output)


def timestamp(ms):
    hours, rest = divmod(ms, 3_600_000)
    mins, rest = divmod(rest, 60_000)
    seconds, millis = divmod(rest, 1000)
    return f"{hours:02}:{mins:02}:{seconds:02}.{millis:03}"


def from_timestamp(value):
    parts = value.split(":")
    seconds, ms = parts[-1].split(".")
    return (int(parts[-3]) * 3_600_000 if len(parts) == 3 else 0) + int(parts[-2]) * 60_000 + int(seconds) * 1000 + int(ms)


def make_captions(path, output):
    sections = re.split(r"\n\s*\n", path.read_text().strip())
    captions = ["WEBVTT", ""]
    for section in sections:
        lines = section.splitlines()
        if " --> " not in lines[0]:
            continue
        start, end = map(from_timestamp, lines[0].split(" --> "))
        if start >= AUDIO_IN + TOTAL or end <= AUDIO_IN:
            continue
        if min(TOTAL, end - AUDIO_IN) - max(0, start - AUDIO_IN) < 250:
            continue
        captions.extend([
            f"{timestamp(max(0, start - AUDIO_IN))} --> {timestamp(min(TOTAL, end - AUDIO_IN))}",
            *lines[1:],
            "",
        ])
    captions.extend(["00:00:23.400 --> 00:00:27.200", "[Instrumental break]", ""])
    output.write_text("\n".join(captions))


def main():
    parser = ArgumentParser()
    parser.add_argument("--gits", type=Path, default=DEFAULT_GITS)
    args = parser.parse_args()
    source = args.gits / "just-stuff"
    change = source / "change-the-default"
    media = {
        "rhythm": change / "Change-The-Default-Rhythm-Cut.mp4",
        "encore": source / "who-gets-the-change/who-gets-the-change-encore-cut.mp4",
        "cover": args.gits / "loftwahfm/music/who-keeps-the-map/cover.jpg",
        "captions": change / "publication/change-the-default-rhythm-1becbd4f-en.vtt",
    }
    hashes = {key: sha(path) for key, path in media.items()}
    if hashes["rhythm"] != CHANGE_HASH or hashes["encore"] != ENCORE_HASH:
        raise SystemExit("The selected original does not match the released SHA-256.")
    card = HERE / "release-sleeve.png"
    build_card(media["cover"], card)
    durations = {}
    for asset, subject, start, duration in SHOT_SPECS:
        path = HERE / f"{asset}.mp4"
        durations[asset] = duration
        frames = duration * 30 // 1000
        if subject == "card":
            pre = ["-loop", "1", "-framerate", "30", "-i", card]
        else:
            pre = ["-ss", f"{start / 1000:.3f}", "-i", media[subject]]
        ffmpeg(*pre, "-vf", "fps=30,scale=1280:720:flags=lanczos,setsar=1,format=yuv420p",
               "-an", "-frames:v", frames, "-c:v", "libx264", "-preset", "fast",
               "-crf", "17", "-threads", "2", "-movflags", "+faststart", path)

    audio = HERE / "change-the-default-premix.wav"
    ffmpeg("-ss", f"{AUDIO_IN / 1000:.3f}", "-i", media["rhythm"],
           "-map", "0:a:0", "-t", str(TOTAL / 1000), "-af",
           "afade=t=in:st=0:d=0.035,afade=t=out:st=34.100:d=0.900",
           "-ar", 48000, "-ac", 2, "-c:a", "pcm_s16le", audio)
    paths = {asset: HERE / f"{asset}.mp4" for asset in durations}
    paths["soundtrack"] = audio
    assets = {key: {"path": path.name, "sha256": sha(path)} for key, path in paths.items()}
    dump("assets.json", assets)
    dump("origin.json", {
        "sources": {
            key: {"filename": path.name, "sha256": hashes[key]}
            for key, path in media.items()
        },
        "shots": [
            {"asset": asset, "source": subject, "source_in_ms": start, "duration_ms": duration}
            for asset, subject, start, duration in SHOT_SPECS
        ],
        "audio_source": "rhythm",
        "audio_source_in_ms": AUDIO_IN,
        "output_duration_ms": TOTAL,
        "photo_credit": {
            "creator": "Leonardo Angelini",
            "work": "Gran Via, Madrid, at night",
            "license": "CC BY 2.0",
            "source_url": "https://commons.wikimedia.org/wiki/File:Gran_Via,_Madrid,_at_night.jpg",
            "license_url": "https://creativecommons.org/licenses/by/2.0/",
            "notes": "Credit retained for original Encore Cut. This derivative uses no city-photo insert."
        },
    })
    for revision in (1, 2):
        assets = CUTS if revision == 1 else [
            asset if asset != "pursuit" else "handoff" for asset in CUTS
        ]
        dump(f"composition-v{revision}.json", {
            "id": "loftwahfm-keep-a-copy",
            "title": f"Who Keeps the Map? | Keep a Copy | V{revision}",
            "shots": [{"assetId": asset, "durationMs": durations[asset]} for asset in assets],
            "totalMs": TOTAL,
            "audioAssetId": "soundtrack",
            "updatedAt": revision
        })
    make_captions(media["captions"], HERE.parent / "keep-a-copy-en.vtt")


if __name__ == "__main__":
    main()
