# App Composer engineering diagrams

Open an editable original in LDraw, or use the matching PNG or SVG in a document or presentation.

App Composer connects a creator’s intent to the work needed to make and run an owned product. It brings together briefs, a chosen agent, reusable capabilities, creative tools and release evidence. The person decides the outcome. The project keeps its source, data and release boundary.

Start with **What App Composer is for**. Its final row is product direction. Use the engineering diagrams to inspect the supported handoffs, permissions and verification steps.

## Composer diagrams

Reviewed Composer source: [d0322a1](https://github.com/loftwah/app-composer/tree/d0322a1c8a6da1c9bad5ebdafd0673e3d7bfc3dc).

- **What App Composer is for** · [Editable](composer/composer-purpose.excalidraw) · [PNG](composer/composer-purpose.png) · [SVG](composer/composer-purpose.svg) — Why Composer exists, who stays in control, and what the platform aims to make possible.
- **Agent and owner authority** · [Editable](composer/composer-agent-and-owner.excalidraw) · [PNG](composer/composer-agent-and-owner.png) · [SVG](composer/composer-agent-and-owner.svg) — How interest becomes a bounded proposal and how a person retains approval and execution authority.
- **Reusable capability contracts** · [Editable](composer/composer-capability-reuse.excalidraw) · [PNG](composer/composer-capability-reuse.png) · [SVG](composer/composer-capability-reuse.svg) — How a reusable building block becomes part of a project without absorbing its ownership.
- **Runtime, release and recovery** · [Editable](composer/composer-release-and-runtime.excalidraw) · [PNG](composer/composer-release-and-runtime.png) · [SVG](composer/composer-release-and-runtime.svg) — The Composer control plane, independent deployments and the checks that support a production claim.
- **Creative production and reuse** · [Editable](composer/composer-creative-pipeline.excalidraw) · [PNG](composer/composer-creative-pipeline.png) · [SVG](composer/composer-creative-pipeline.svg) — How owner references become editable media and approved public work.
- **Media Studio runtime and handoffs** · [Editable](composer/composer-media-studio-runtime.excalidraw) · [PNG](composer/composer-media-studio-runtime.png) · [SVG](composer/composer-media-studio-runtime.svg) — The studio keeps its own projects and media, exposes a scoped handoff, and publishes selected outputs.
- **Composer public page map** · [Editable](composer/composer-public-page-map.excalidraw) · [PNG](composer/composer-public-page-map.png) · [SVG](composer/composer-public-page-map.svg) — Find apps, try a demo, build, and browse published work.
- **Build and compose** · [Editable](composer/composer-build-and-compose.excalidraw) · [PNG](composer/composer-build-and-compose.png) · [SVG](composer/composer-build-and-compose.svg) — From an idea to a validated brief, editable model and working application.
- **Publish and operate** · [Editable](composer/composer-publish-and-operate.excalidraw) · [PNG](composer/composer-publish-and-operate.png) · [SVG](composer/composer-publish-and-operate.svg) — Draft, publish, review and maintain the same owned application.
- **Creative tools and outputs** · [Editable](composer/composer-creative-tools.excalidraw) · [PNG](composer/composer-creative-tools.png) · [SVG](composer/composer-creative-tools.svg) — Which tool owns the work and where to find finished public examples.
- **Guides and agent handoffs** · [Editable](composer/composer-learning-and-reference.excalidraw) · [PNG](composer/composer-learning-and-reference.png) · [SVG](composer/composer-learning-and-reference.svg) — Where to learn, pick a prompt, or inspect the maintained reference.
- **Independent apps and handoffs** · [Editable](composer/composer-independent-apps.excalidraw) · [PNG](composer/composer-independent-apps.png) · [SVG](composer/composer-independent-apps.svg) — Where the independent Composer apps fit and how a real pair works together.
- **Does this need its own page?** · [Editable](composer/composer-public-page-decision.excalidraw) · [PNG](composer/composer-public-page-decision.png) · [SVG](composer/composer-public-page-decision.svg) — A public page review flowchart for spotting duplicate jobs and putting new pages under the right parent.

## Related project architecture

Each diagram records the project source revision it was reviewed against.

- **App Composer** · [Editable](related-projects/composer-architecture.excalidraw) · [PNG](related-projects/composer-architecture.png) · [SVG](related-projects/composer-architecture.svg) — Reviewed 00d0a6c. Owner intent, agent proposal and independent delivery stay separate.
- **LDraw** · [Editable](related-projects/ldraw-architecture.excalidraw) · [PNG](related-projects/ldraw-architecture.png) · [SVG](related-projects/ldraw-architecture.svg) — Reviewed 6ef2de9. A local portfolio editor with real artwork, editable architecture and a presentation view.
- **Paperwork** · [Editable](related-projects/paperwork-architecture.excalidraw) · [PNG](related-projects/paperwork-architecture.png) · [SVG](related-projects/paperwork-architecture.svg) — Reviewed d01603e. PDF fields, ink, signatures and printing never leave the browser.
- **Here / there** · [Editable](related-projects/herethere-architecture.excalidraw) · [PNG](related-projects/herethere-architecture.png) · [SVG](related-projects/herethere-architecture.svg) — Reviewed 376129c. Visitor photographs and postcards pass an explicit owner review.
- **Linkarooie** · [Editable](related-projects/linkarooie-architecture.excalidraw) · [PNG](related-projects/linkarooie-architecture.png) · [SVG](related-projects/linkarooie-architecture.svg) — Reviewed 2f9280d. One public profile, app-owned records and approved Guestbook media.
- **Link Check** · [Editable](related-projects/linkcheck-architecture.excalidraw) · [PNG](related-projects/linkcheck-architecture.png) · [SVG](related-projects/linkcheck-architecture.svg) — Reviewed 99d0132. A bounded public-page inspection, not a crawler or trusted proxy.
- **Carry / forward** · [Editable](related-projects/carry-architecture.excalidraw) · [PNG](related-projects/carry-architecture.png) · [SVG](related-projects/carry-architecture.svg) — Reviewed f3d279f. A fictional memory vault that moves as an encrypted local file.
- **Hello World** · [Editable](related-projects/hello-architecture.excalidraw) · [PNG](related-projects/hello-architecture.png) · [SVG](related-projects/hello-architecture.svg) — Reviewed 8efc6a4. The smallest real release: one page, one origin, no hidden backend.
- **Launch Kit** · [Editable](related-projects/launchkit-architecture.excalidraw) · [PNG](related-projects/launchkit-architecture.png) · [SVG](related-projects/launchkit-architecture.svg) — Reviewed 4e248c0. Local artwork becomes checked icons, install assets and share images.
- **Asset Hunter** · [Editable](related-projects/assethunter-architecture.excalidraw) · [PNG](related-projects/assethunter-architecture.png) · [SVG](related-projects/assethunter-architecture.svg) — Reviewed e7edea3. A rights-aware catalogue of possibilities, not a pile of unlicensed files.
- **MAX** · [Editable](related-projects/max-architecture.excalidraw) · [PNG](related-projects/max-architecture.png) · [SVG](related-projects/max-architecture.svg) — Reviewed ac93ce6. A software prototype and device boundary that does not claim a finished walker.
- **Protocol 11** · [Editable](related-projects/protocol11-architecture.excalidraw) · [PNG](related-projects/protocol11-architecture.png) · [SVG](related-projects/protocol11-architecture.svg) — Reviewed 4dac378. A local card table with optional rooms, invitations and persistent platform records.
- **Bubbles** · [Editable](related-projects/bubbles-architecture.excalidraw) · [PNG](related-projects/bubbles-architecture.png) · [SVG](related-projects/bubbles-architecture.svg) — Reviewed 9860857. A static game with local saves, authored worlds and no account barrier.
- **SHOALSHOT** · [Editable](related-projects/shoalshot-architecture.excalidraw) · [PNG](related-projects/shoalshot-architecture.png) · [SVG](related-projects/shoalshot-architecture.svg) — Reviewed 2aa1805. A local-first dive with authored specimens, launchers and a local share card.
- **LOFTWAH FIGHTER** · [Editable](related-projects/fighter-architecture.excalidraw) · [PNG](related-projects/fighter-architecture.png) · [SVG](related-projects/fighter-architecture.svg) — Reviewed 00e4abb. Local battles, a generated roster and a small platform around suggestions.
- **Pirates** · [Editable](related-projects/pirates-architecture.excalidraw) · [PNG](related-projects/pirates-architecture.png) · [SVG](related-projects/pirates-architecture.svg) — Reviewed 7cf87fe. A source-first reconstruction. The original game is the authority, not a new style.
- **LoftwahFM** · [Editable](related-projects/loftwahfm-architecture.excalidraw) · [PNG](related-projects/loftwahfm-architecture.png) · [SVG](related-projects/loftwahfm-architecture.svg) — Reviewed 64f53a3. A music catalogue, continuous player and shared game-radio service.
- **Woodhouse** · [Editable](related-projects/woodhouse-architecture.excalidraw) · [PNG](related-projects/woodhouse-architecture.png) · [SVG](related-projects/woodhouse-architecture.svg) — Reviewed a25f6fc. Independent projects become a reviewed, dated public record.

The [Composer diagram atlas](https://composer.loftwah.com/diagrams) also keeps its committed Get Ready, approval, environment and contribution diagrams in Composer’s `public/diagrams/ldraw/`.
