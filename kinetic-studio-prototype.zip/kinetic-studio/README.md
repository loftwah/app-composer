# App Composer: kinetic studio

A standalone hero **geometry and interaction prototype**, made 13 November 2026. It is not the production homepage and is not an art-matched implementation of the accompanying illustration. Nothing was published, committed, deployed or connected to production services.

## Open it

Unzip the complete folder, then open `index.html` in a current desktop browser. It uses a classic, locally bundled script rather than runtime module/CDN imports. Browser local-file policies vary; a normal static server is the alternative:

```sh
cd kinetic-studio
python3 -m http.server 4178 --bind 127.0.0.1
```

Visit `http://127.0.0.1:4178`. No build, account, API key or package installation is required to view the included bundle. The prototype is local; its explicit product links navigate to the actual Composer site.

## What to try

- **Paperwork:** move “Pull the paper” with the pointer or keyboard arrow keys. The paper mesh changes curvature and the camera responds. “Stamp the page” lowers the press and marks an invented page. Repeated presses work. Product context correctly identifies browser-local PDF forms.
- **LDraw:** select the drawing mode. The slider raises and lowers real 3D steps and supports from a flat drawing. “Build the drawing” toggles the raised/flat result. Product context identifies LDraw as an independent drawing app.
- **Analytics:** turn the lens and inspect successive fictional connections in a separate instrument. There are no invented live counts. Context explains that Composer reporting counts recorded requests and supported actions, not people.
- **Pause motion:** stops ambient motion while direct controls still work. With reduced-motion enabled, control changes apply directly, ambient motion is disabled, and the control reports “Reduced motion.”
- Use Tab/Enter for buttons and arrow keys on the native range input. Each mode retains its control setting independently.

The orange press, stepped drawing, pencil, curling paper, gears, railings and lens are procedural Three.js geometry. The illustration is only art direction and a static fallback, not a screenshot plane. No mascot was added. The two independent apps and Composer reporting are not represented as a live data pipeline.

## Included

- `index.html`, `studio.css`: ordinary live HTML, responsive layout, product copy and accessible controls.
- `studio.js`: authored scene, materials, lighting/shadows, lifecycle and interactions.
- `scene-state.mjs`: testable paper deformation, drawing geometry and mode content.
- `studio.bundle.js`: self-contained production-format IIFE bundle.
- `vendor/`: official Three.js 0.187.0 modules and MIT license, pinned locally.
- `checks.test.mjs`: focused geometry, asset, fallback and lifecycle checks.
- `composer-mark.svg`: byte-identical copy of the approved Composer icon.
- `space.woff2`: existing first-party typography copied from the repository.
- `studio-that-prints-itself-concept.png`, `ART_DIRECTION.md`: preserved concept and direction.

## Checks and limits

Passed: JavaScript syntax check; esbuild bundle; **12 focused Node tests**, including full-bundle execution in a simulated GPU-failure environment with usable mode/slider/action controls. Paper values remain finite across the control domain; drawing actually changes height; canonical icon bytes match; local assets exist; no remote JS is used; initial disabled controls and truthful static status cover an unloaded bundle; bfcache lifecycle guards preserve resources. The bfcache check is a source guard, not a real browser history test.

Normal local static preview was attempted. The server process returned a running session, but both a localhost request and the available CUA browser could not connect (`ERR_CONNECTION_REFUSED`). That session was stopped. A normal CUA file URL attempt was rejected because that browser only allows HTTP/HTTPS; no security restriction was bypassed. Consequently **rendered GPU appearance, real keyboard/focus behavior, responsive phone/desktop pixels, history restoration and performance remain unverified**. No FPS claim is made. The code and simulated fallback tests do not establish visual quality or production readiness.

The actual Impeccable skill/context tool was unavailable in this executor. Repository design/product guidance was read; no Impeccable execution is claimed.

Renderer: mature `WebGLRenderer` backend, not a claim of universal WebGPU support. DPR is capped at 1.6; render scheduling stops when hidden/offscreen; paused/reduced-motion scenes render on demand; dynamic paper normals update only when controls change; resources are disposed on final unload and retained for bfcache. GPU failure/context loss shows the illustration and retains HTML controls/product links. Bundle failure leaves disabled demonstration controls and useful normal links.

## Rebuild and check in the repository

```sh
node_modules/.pnpm/esbuild@0.28.2/node_modules/esbuild/bin/esbuild \
  output/hero-composition/kinetic-studio/studio.js \
  --bundle --minify --format=iife --target=es2022 --legal-comments=eof \
  --outfile=output/hero-composition/kinetic-studio/studio.bundle.js
node --check output/hero-composition/kinetic-studio/studio.js
node --test output/hero-composition/kinetic-studio/checks.test.mjs
```

After unzipping anywhere, run `node --test checks.test.mjs` from the extracted folder. No package installation or original repository is required. The canonical-mark check compares a pinned SHA-256 verified against the repository's approved mark at packaging time.

Dependency provenance: official `https://registry.npmjs.org/three/-/three-0.187.0.tgz`; verified SHA-512 (base64) `Qiu7R+Cmh8CstZsY1uJOSWnVlfo7ZtNLV7mF8Jltk3LB3AtDu9cRZlcnRKkAk8Y4z6KKw35z7Y7Urd7jWY8etA==`. Only required browser modules and license were retained. The temporary package archive was removed. No repository dependency/lockfile was changed.
