import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import vm from 'node:vm';
import {paperPoint,drawingPoint,clamp01,modeCopy} from './scene-state.mjs';
const read=name=>readFileSync(new URL(name,import.meta.url),'utf8');
test('paper deformation is finite across the full control domain',()=>{
  for(let p=0;p<=1;p+=.05)for(let t=0;t<=1;t+=.01)for(const width of [-1,0,1])assert.ok(paperPoint(t,width,p).every(Number.isFinite));
});
test('pulling changes the actual paper surface',()=>{
  assert.notDeepEqual(paperPoint(.5,0,0),paperPoint(.5,0,1));
  assert.ok(paperPoint(.5,0,1)[1]>paperPoint(.5,0,0)[1]);
});
test('drawing begins flat and becomes a multi-level structure',()=>{
  assert.equal(drawingPoint(12,0)[1],.12);
  assert.ok(drawingPoint(12,1)[1]>4);
  assert.ok(drawingPoint(1,1)[1]<drawingPoint(12,1)[1]);
});
test('progress clamps finite and invalid inputs',()=>{
  assert.equal(clamp01(-1),0);assert.equal(clamp01(3),1);assert.equal(clamp01(NaN),0);
});
test('three distinct modes, with fictional analytics wording',()=>{
  for(const mode of ['press','draw','inspect'])assert.ok(modeCopy(mode).action);
  assert.match(modeCopy('inspect').readout,/fictional.*not live analytics/i);assert.equal(modeCopy('invalid'),null);
});
test('all required local assets exist, with no remote JavaScript',()=>{
  const html=read('index.html');for(const asset of ['studio.bundle.js','studio.css','studio-that-prints-itself-concept.png','composer-mark.svg','space.woff2'])assert.ok(existsSync(new URL(asset,import.meta.url)),asset);
  assert.doesNotMatch(html,/<script[^>]+src=["']https?:/);assert.match(html,/type="range"/);assert.match(html,/aria-live="polite"/);
});
test('canonical Composer mark remains byte-identical',()=>{
  // Pinned SHA-256 of the approved public/brand/composer-icon-20261022b.svg.
  const a=readFileSync(new URL('composer-mark.svg',import.meta.url));assert.equal(createHash('sha256').update(a).digest('hex'),'cae783937fb91fc2405596f4070f5834c7df7fcd5616fef9f9661f581fbf4326');
});
test('source includes render-lifecycle and GPU fallback guardrails',()=>{
  const source=read('studio.js');assert.match(source,/Math\.min\(devicePixelRatio\|\|1,1\.6\)/);assert.match(source,/document\.hidden/);assert.match(source,/IntersectionObserver/);assert.match(source,/webglcontextlost/);assert.match(source,/prefers-reduced-motion/);assert.match(source,/resources\.forEach\(resource=>resource\.dispose/);
});
function fallbackHarness(reduced=false){
  class Element{
    constructor(){this.listeners={};this.attributes={};this.firstChild={textContent:''};this.classList={add(){},remove(){}};this.value='35';this.dataset={};this.hidden=false;this.textContent='';}
    addEventListener(type,fn){this.listeners[type]=fn;}setAttribute(k,v){this.attributes[k]=v;}replaceChildren(...nodes){this.children=nodes;}
  }
  const elements=Object.fromEntries(['scene','world','build','pause','announcement','readout','range-label','action','instruction','chapter-number','chapter-phrase','range-help','build-value','renderer-state','product-summary','tool-link'].map(k=>['#'+k,new Element()]));
  const buttons=['press','draw','inspect'].map(mode=>Object.assign(new Element(),{dataset:{mode}}));
  const document={querySelector:s=>elements[s],querySelectorAll:selector=>selector==='[data-demo-control]'?[...buttons,elements['#pause'],elements['#build'],elements['#action']]:buttons,createElement:()=>new Element(),createTextNode:text=>({textContent:text}),hidden:false};
  const window={addEventListener(){}};
  const context={document,window,matchMedia:()=>({matches:reduced,addEventListener(){}}),requestAnimationFrame:()=>{throw Error('No render loop should start without GPU')},cancelAnimationFrame(){},console:{warn(){},error(){},log(){}},performance:{now:()=>0},setTimeout,clearTimeout};
  vm.runInNewContext(read('studio.bundle.js'),context,{timeout:3000});
  return {elements,buttons};
}
test('GPU failure retains working mode, slider and stamp controls',()=>{
  const {elements:e,buttons}=fallbackHarness();assert.match(e['#renderer-state'].textContent,/3D not available/);assert.equal(e['#pause'].hidden,true);
  e['#action'].listeners.click();assert.match(e['#announcement'].textContent,/page stamped/i);
  buttons[1].listeners.click();assert.equal(e['#range-label'].textContent,'Lift the drawing');e['#action'].listeners.click();assert.equal(e['#build'].value,'100');assert.match(e['#announcement'].textContent,/three dimensions/);
  e['#build'].value='12';e['#build'].listeners.input();assert.equal(e['#build-value'].value,'12%');
  buttons[2].listeners.click();e['#action'].listeners.click();assert.match(e['#announcement'].textContent,/Fictional demonstration/);
  buttons[0].listeners.click();e['#action'].listeners.click();assert.match(e['#announcement'].textContent,/page stamped/i);
});
test('reduced motion initializes with an explicit reduced-motion state',()=>{
  const {elements:e}=fallbackHarness(true);assert.equal(e['#pause'].disabled,true);assert.equal(e['#pause'].attributes['aria-pressed'],'true');assert.match(e['#pause'].firstChild.textContent,/Reduced motion/);
});

test('unloaded bundle leaves a truthful static view and disabled demo controls',()=>{
  const html=read('index.html');assert.match(html,/Static art-direction view/);assert.doesNotMatch(html,/Loading the mechanical/);
  assert.equal((html.match(/<button disabled data-demo-control/g)||[]).length,5);assert.match(html,/<input disabled data-demo-control id="build"/);
  assert.match(html,/Make <br>/);
});
test('back-forward cache restoration preserves renderer resources',()=>{
  const source=read('studio.js');assert.match(source,/if\(event\.persisted\)return;[^]*?alive=false;resources/);assert.match(source,/pageshow[^]*?event\.persisted&&alive[^]*?requestRender/);
});
