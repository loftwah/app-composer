# The studio that prints itself

Concept and prototype direction, 13 November 2026. This is a new experiential
proposal, not the earlier floating-panel hero and not an approved production
release. The accompanying PNG is generated art direction, not a browser capture.

## The opening

A single impossible workshop fills the browser. A recognizable orange Paperwork
press anchors the foreground. A pencil draws a line that rises into folded paper
architecture. A separate evidence lens occupies the upper depth of the scene.
The camera can enter this world; it is not three images moving over a background.

Keep the approved App Composer merging-block mark intact. Use authored ink
contours, warm paper, orange enamel, midnight blue structure and restrained teal
accents. The Woodhouse share gallery contributes specific action, purposeful
exaggeration, confident composition, texture and finish, not a grid layout or its
characters. No new mascot is required.

Live HTML supplies the headline and explanation:

Make something worth keeping.
App Composer is a studio for building and running apps with your coding agent on
Cloudflare. Keep control of the source and data.

The main Get Ready action remains visible and operable without entering the
scene. Normal document scrolling must never be trapped.

## What the browser should do

One continuous pull/build control deforms the cream sheet, reveals dimensional
ink, raises the drawing into architecture and moves the camera through the same
space. Paperwork's oversized mechanism makes a small finished fictional page.
LDraw's shapes can visibly become a structure and remain changeable. The separate
analytics instrument offers a new way to inspect evidence, not a decorative
up-and-right growth chart. Short paper-offcut bursts emphasize a physical event;
there is no perpetual confetti or particle wallpaper.

The actual product links stay ordinary links. Paperwork keeps documents in the
browser; LDraw owns its independent drawings; analytics reports supported
recorded activity, not people. The scene uses fictional demonstration state and
does not send documents, signatures or drawings to analytics. Never substitute
invented numbers for live usage data.

## Technology decision

Three.js 0.187.0 was verified from the official npm package metadata on 13
November 2026. Its WebGPURenderer offers WebGPU with automatic WebGL2 fallback
and TSL-based materials. The official manual still calls that renderer
experimental. A WebGLRenderer prototype is appropriate for the first interaction
proof; choosing WebGPU later must be justified by measured rendering needs, not
by a badge or an unsupported claim of universal browser support.

Production art should use authored meshes and a deliberate ink/halftone material
rather than ship a collection of primitive shapes as the finished world. The
prototype's geometry is an interaction blockout. Preserve its continuous camera,
paper deformation and physical causality while replacing weak art with the
approved visual treatment. The concept image is a finish target, not a texture
to lay behind fake 3D cards.

Sources:
- https://threejs.org/manual/pages/webgpurenderer
- https://developer.mozilla.org/en-US/docs/Web/API/WebGPU_API
- https://registry.npmjs.org/three/latest (version checked during this task)
- https://woodhouse.loftwah.com/share/

## Performance and access

Show the poster and useful HTML immediately. Load the GPU experience separately,
cap device pixel ratio, stop rendering when hidden, dispose resources, and keep a
Pause control. Use explicit low-motion composed states for reduced motion. GPU
initialization/context failure must leave a beautiful poster plus the same
product explanation and real actions. Keyboard controls must operate the same
state transitions as pointer controls. Do not autoplay audio, hijack scrolling,
make an animation necessary to reach an app, or claim a frame rate that was not
measured on real target devices.

The acceptance is the actual browser experience at representative desktop and
phone widths, with rendering, motion, fallback, keyboard access, loading and the
three meaningful actions inspected. Compiling source is not visual acceptance.

## Superseded work

The incremental branch codex/studio-hero-motion-20261113 was published before the
owner requested this larger rethink. Its head is 70adbd01548ec0273d11807cdac98f55cb17f256.
No PR, merge or deployment was created for it. Do not mistake that branch for
this new concept or merge it as the final response to the broader request.
