import * as THREE from './vendor/three.module.js';
import {paperPoint, drawingPoint, clamp01, modeCopy} from './scene-state.mjs';

// Everything in this scene is procedural geometry. The concept image is a fallback,
// never a plane in the 3D scene. Demonstration interactions do not call any service.
const $ = selector => document.querySelector(selector);
const stage = $('#scene'), canvas = $('#world'), range = $('#build');
const motionQuery = matchMedia('(prefers-reduced-motion: reduce)');
let reduced = motionQuery.matches, paused = reduced, mode = 'press';
let progress = .35, targetProgress = .35, stampAt = -Infinity, inspection = 0;
const modeProgress = {press:.35, draw:.54, inspect:.5};
let renderer, scene, camera, raf = 0, active = true, last = 0, alive = true;
let elapsed = 0, pointer = {x:0,y:0}, cameraSettled = false;
const ink = 0x0c1921, orange = 0xfc5b05, paper = 0xf2e6cf;
const mats = {}, dynamic = {};
const targetCamera = new THREE.Vector3(), targetLook = new THREE.Vector3();
const look = new THREE.Vector3(0,2.5,0);
const handles = [], resources = new Set();
function announce(text){ $('#announcement').textContent = text; }
function setReadout(text){ $('#readout').replaceChildren(Object.assign(document.createElement('b'),{textContent:modeCopy(mode).name}),document.createTextNode(' · '+text)); }
function syncPause(){ $('#pause').setAttribute('aria-pressed',String(paused||reduced)); $('#pause').disabled=reduced; $('#pause').firstChild.textContent = reduced ? 'Reduced motion ' : paused ? 'Resume motion ' : 'Pause motion '; }
function requestRender(){ if(!raf && alive && active && !document.hidden && renderer) raf=requestAnimationFrame(frame); }
function uiMode(next){
  modeProgress[mode]=targetProgress;mode=next;targetProgress=modeProgress[mode];progress=targetProgress;
  range.value=String(Math.round(progress*100));$('#build-value').value=range.value+'%';
  const c=modeCopy(mode);
  $('#product-summary').textContent=c.context;$('#tool-link').href=c.href;$('#tool-link').textContent='Open '+c.name+' ↗';
  document.querySelectorAll('[data-mode]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.mode===mode)));
  $('#range-label').textContent=c.label;
  $('#action').firstChild.textContent=c.action+' ';
  $('#instruction').textContent=c.instruction;
  $('#chapter-number').textContent=({press:'01 / PAPERWORK',draw:'02 / LDRAW',inspect:'03 / ANALYTICS'})[mode];
  $('#chapter-phrase').textContent=c.caption;
  $('#range-help').textContent=mode==='press'?'Use the arrow keys to pull and curl the paper.':mode==='draw'?'Use the arrow keys to lift the drawing into a three-dimensional structure.':'Use the arrow keys to turn the fictional evidence instrument.';
  setReadout(c.readout); announce(c.name+'. '+c.readout); cameraSettled=false;
  if(reduced || paused) progress=targetProgress;
  requestRender();
}
document.querySelectorAll('[data-mode]').forEach(button=>button.addEventListener('click',()=>uiMode(button.dataset.mode)));
range.addEventListener('input',()=>{
  targetProgress=Number(range.value)/100; $('#build-value').value=range.value+'%'; cameraSettled=false;
  if(reduced || paused) progress=targetProgress;
  requestRender();
});
$('#pause').addEventListener('click',()=>{paused=!paused;syncPause();announce(paused?'Ambient motion paused. All controls still work.':'Ambient motion resumed.');requestRender();});
$('#action').addEventListener('click',()=>{
  if(mode==='press'){
    stampAt=(paused||reduced)?-Infinity:elapsed; if(dynamic.stampMark)dynamic.stampMark.visible=true;
    setReadout('Stamped: a fictional page, made here in your browser.');announce('Fictional page stamped.');
  }else if(mode==='draw'){
    targetProgress=targetProgress>.92?.08:1;range.value=String(Math.round(targetProgress*100));$('#build-value').value=range.value+'%';
    setReadout(targetProgress===1?'The drawing rises into a structure.':'The structure returns to its drawing.');announce(targetProgress===1?'Drawing lifted into three dimensions.':'Drawing returned to the page.');
  }else{
    inspection=(inspection+1)%3;
    const messages=['A selected source connects to the central question.','A second source offers a different connection.','A third source remains separate for comparison.'];
    setReadout(messages[inspection]+' Fictional demonstration.');announce(messages[inspection]+' Fictional demonstration.');
  }
  if(reduced || paused)progress=targetProgress;cameraSettled=false;requestRender();
});
document.querySelectorAll('[data-demo-control]').forEach(control=>{control.disabled=false;});
$('#pause').hidden=false;
syncPause();
motionQuery.addEventListener('change',e=>{reduced=e.matches;if(reduced)paused=true;syncPause();cameraSettled=false;requestRender();});
function material(color,options={}){const m=new THREE.MeshStandardMaterial({color,roughness:.64,metalness:.16,...options});resources.add(m);return m;}
function mesh(geometry,mat,parent,pos=[0,0,0],rotation=[0,0,0]){
  resources.add(geometry); const m=new THREE.Mesh(geometry,mat);m.position.set(...pos);m.rotation.set(...rotation);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;
}
function box(w,h,d,mat,parent,pos,rot){return mesh(new THREE.BoxGeometry(w,h,d),mat,parent,pos,rot);}
function cylinder(r1,r2,h,mat,parent,pos,rot,segments=32){return mesh(new THREE.CylinderGeometry(r1,r2,h,segments),mat,parent,pos,rot);}
function ring(r,t,mat,parent,pos,rot){return mesh(new THREE.TorusGeometry(r,t,12,72),mat,parent,pos,rot);}
function rod(a,b,r,mat,parent){const start=new THREE.Vector3(...a),end=new THREE.Vector3(...b);const m=cylinder(r,r,start.distanceTo(end),mat,parent,start.clone().add(end).multiplyScalar(.5).toArray());m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),end.sub(start).normalize());return m;}
function sphere(r,mat,parent,pos){return mesh(new THREE.SphereGeometry(r,24,16),mat,parent,pos);}
function edge(object,color=0x14262d){const g=new THREE.EdgesGeometry(object.geometry,30);resources.add(g);const mat=new THREE.LineBasicMaterial({color,transparent:true,opacity:.7});resources.add(mat);const lines=new THREE.LineSegments(g,mat);object.add(lines);return object;}
function gear(radius,teeth,parent,pos,mat=mats.orange){
  const g=new THREE.Group();g.position.set(...pos);parent.add(g);
  ring(radius*.7,radius*.24,mat,g,[0,0,0]);
  cylinder(radius*.23,radius*.23,.32,mats.cream,g,[0,0,0],[Math.PI/2,0,0]);
  for(let i=0;i<teeth;i++){const a=i/teeth*Math.PI*2;box(radius*.22,radius*.27,.27,mat,g,[Math.cos(a)*radius,Math.sin(a)*radius,0],[0,0,a-Math.PI/2]);}
  handles.push(g);return g;
}
function rivets(parent,width,y,z){for(const x of [-width/2,width/2]){sphere(.085,mats.metal,parent,[x,y,z]);}}
function makePress(world){
  const press=new THREE.Group();press.position.set(-4.25,.1,.8);press.rotation.y=.08;world.add(press);
  edge(box(3.65,.32,3.0,mats.orange,press,[0,.2,0]));
  box(3.85,.13,3.16,mats.dark,press,[0,.02,0]);
  for(const x of [-1.35,1.35]){
    edge(box(.4,3.3,.6,mats.orange,press,[x,1.85,-.3]));
    cylinder(.23,.23,.14,mats.metal,press,[x,.4,.6],[Math.PI/2,0,0]);
    box(.85,.2,1.15,mats.orange,press,[x,.45,-.25]);
  }
  edge(box(3.1,.6,1,mats.orange,press,[0,3.35,-.3]));rivets(press,2.5,3.35,.24);
  cylinder(.37,.37,2.75,mats.dark,press,[0,1,-.32],[0,0,Math.PI/2]);
  for(const x of [-1.55,1.55])cylinder(.46,.46,.25,mats.metal,press,[x,1,-.32],[0,0,Math.PI/2]);
  cylinder(.17,.17,2.3,mats.metal,press,[0,2.4,-.3]);
  const stamp=new THREE.Group();stamp.position.set(0,1.7,-.3);press.add(stamp);
  edge(box(1.4,.45,1.04,mats.dark,stamp,[0,0,0]));box(1.23,.11,.85,mats.orange,stamp,[0,-.27,0]);dynamic.stamp=stamp;
  const lever=new THREE.Group();lever.position.set(1.65,2.6,-.3);press.add(lever);rod([0,0,0],[0,1.4,.7],.105,mats.orange,lever);sphere(.23,mats.dark,lever,[0,1.42,.72]);dynamic.lever=lever;
  cylinder(.42,.42,.28,mats.orange,press,[1.66,2.6,-.3],[0,0,Math.PI/2]);
  for(let i=0;i<7;i++)box(2.3,.035,1.6,mats.cream,press,[-.15,.49+i*.043,1.0],[0,.01*i,0]);
  // A real page on the press with invented drawing marks, not a product screenshot.
  box(2.1,.03,1.5,mats.cream,press,[0,.84,1.45]);
  for(let i=0;i<4;i++)box(1.05-i*.13,.012,.045,mats.dark,press,[-.25,.865,1.0+i*.14]);
  const mark=new THREE.Group();mark.position.set(.45,.87,1.8);press.add(mark);mark.visible=false;
  rod([-.35,0,0],[-.1,0,.2],.035,mats.orange,mark);rod([-.1,0,.2],[.4,0,-.27],.035,mats.orange,mark);dynamic.stampMark=mark;
  gear(.55,12,press,[-1.6,2.05,.11]);
  // Small embossed label as geometry, deliberately without fabricated metrics.
  box(.9,.18,.03,mats.cream,press,[0,3.35,.22]);
  for(let i=0;i<5;i++)box(.04,.1,.025,mats.dark,press,[-.25+i*.13,3.35,.245]);
}
function makePaper(world){
  const columns=100,rows=10,positions=[],uvs=[],indices=[];
  for(let i=0;i<=columns;i++)for(let j=0;j<=rows;j++){positions.push(0,0,0);uvs.push(i/columns,j/rows);if(i<columns&&j<rows){const a=i*(rows+1)+j,b=a+rows+1;indices.push(a,b,a+1,b,b+1,a+1);}}
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));geometry.setIndex(indices);
  const sheet=mesh(geometry,mats.paper,world);dynamic.sheet=sheet;dynamic.paperSize={columns,rows};
  const paths=[];for(const across of [-1,1]){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(new Array((columns+1)*3).fill(0),3));resources.add(g);const mat=new THREE.LineBasicMaterial({color:0x997a56});resources.add(mat);const l=new THREE.Line(g,mat);world.add(l);paths.push(l);}dynamic.paperEdges=paths;
  // A second curling offcut makes the continuous world legible from the silhouette.
  const curve=new THREE.CatmullRomCurve3([new THREE.Vector3(-7,.7,-.5),new THREE.Vector3(-7.6,2.7,-.4),new THREE.Vector3(-6.5,4.5,-.5),new THREE.Vector3(-4.2,5.9,-1.4),new THREE.Vector3(-1.2,6.1,-2.3),new THREE.Vector3(.5,7.5,-2.4)]);
  const ribbonPositions=[],ribbonIndex=[];
  for(let i=0;i<=90;i++){const p=curve.getPoint(i/90);for(let j=0;j<2;j++)ribbonPositions.push(p.x,p.y,p.z+(j-.5)*.7);if(i<90){const a=i*2;ribbonIndex.push(a,a+2,a+1,a+2,a+3,a+1);}}
  const rg=new THREE.BufferGeometry();rg.setAttribute('position',new THREE.Float32BufferAttribute(ribbonPositions,3));rg.setIndex(ribbonIndex);rg.computeVertexNormals();mesh(rg,mats.paper,world);
}
function makeDrawing(world){
  const g=new THREE.Group();g.position.set(.05,1.05,1.1);world.add(g);dynamic.drawing=g;
  cylinder(1.95,2.0,.16,mats.cream,g,[0,-.05,0],undefined,64);
  ring(1.73,.016,mats.dark,g,[0,.04,0],[Math.PI/2,0,0]);
  for(let i=0;i<8;i++){const a=i*Math.PI/4;rod([Math.cos(a)*1.55,.055,Math.sin(a)*1.55],[Math.cos(a)*1.83,.055,Math.sin(a)*1.83],.012,mats.dark,g);}
  dynamic.steps=[];dynamic.struts=[];
  for(let i=0;i<13;i++){
    const step=edge(box(1.25,.11,.68,i%3===0?mats.orange:mats.cream,g,[0,0,0]));step.rotation.y=-i/12*Math.PI*1.55;dynamic.steps.push(step);
    const column=cylinder(.025,.025,1,mats.teal,g);dynamic.struts.push(column);
  }
  const spine=new THREE.Group();g.add(spine);dynamic.spine=spine;
  rod([0,.1,0],[0,4.9,0],.065,mats.orange,spine);
  // Oversized hexagonal pencil, a tool instead of an invented mascot.
  const pencil=new THREE.Group();pencil.position.set(-.8,6.0,1.3);pencil.rotation.z=-.26;world.add(pencil);dynamic.pencil=pencil;
  cylinder(.24,.24,2.45,mats.orange,pencil,[0,0,0],undefined,6);
  cylinder(.25,.25,.25,mats.cream,pencil,[0,1.32,0],undefined,24);
  cylinder(.21,.21,.18,mats.dark,pencil,[0,1.51,0],undefined,24);
  cylinder(.0,.24,.65,mats.wood,pencil,[0,-1.55,0],[0,0,Math.PI],6);
  cylinder(0,.065,.27,mats.dark,pencil,[0,-1.96,0],[0,0,Math.PI],6);
  for(let i=0;i<3;i++)rod([-.18+i*.17,-1.12,.16],[-.18+i*.17,1.15,.16],.009,mats.cream,pencil);
}
function makeLens(world){
  const base=new THREE.Group();base.position.set(4.4,.1,-1.5);base.rotation.y=-.25;world.add(base);
  cylinder(1.7,1.95,.3,mats.dark,base,[0,.18,0],undefined,64);
  cylinder(1.45,1.7,.2,mats.orange,base,[0,.43,0],undefined,64);
  cylinder(.55,.75,2.0,mats.dark,base,[0,1.4,0]);
  ring(1.4,.06,mats.teal,base,[0,2.3,0],[Math.PI/2,0,0]);
  for(let i=0;i<10;i++){const a=i/10*Math.PI*2;rod([Math.cos(a)*1.4,1.95,Math.sin(a)*1.4],[Math.cos(a)*1.4,2.3,Math.sin(a)*1.4],.024,mats.teal,base);}
  const lens=new THREE.Group();lens.position.set(0,4,0);base.add(lens);dynamic.lens=lens;
  ring(1.7,.15,mats.orange,lens,[0,0,0]);ring(1.49,.055,mats.cream,lens,[0,0,.11]);ring(1.87,.04,mats.metal,lens,[0,0,-.06]);
  for(let i=0;i<24;i++){const a=i/24*Math.PI*2;box(.14,.26,.18,mats.orange,lens,[Math.cos(a)*1.83,Math.sin(a)*1.83,-.07],[0,0,a-Math.PI/2]);}
  // Transparent geometric lens and dimensional evidence, never a dashboard plane.
  const glass=mesh(new THREE.CircleGeometry(1.46,64),mats.glass,lens,[0,0,.03]);glass.castShadow=false;glass.receiveShadow=false;
  const orrery=new THREE.Group();lens.add(orrery);dynamic.orrery=orrery;
  ring(1.2,.019,mats.teal,orrery,[0,0,-.15],[.55,.2,.1]);ring(.85,.022,mats.cream,orrery,[0,0,0],[.2,.8,0]);
  sphere(.2,mats.orange,orrery,[0,0,0]);dynamic.nodes=[];
  const pts=[[-.85,.62,.1],[.85,.5,-.2],[.3,-.92,.3]];
  for(let i=0;i<3;i++){const p=pts[i];rod([0,0,0],p,.021,mats.teal,orrery);const node=sphere(.14,mats.cream,orrery,p);dynamic.nodes.push(node);ring(.23,.014,mats.orange,orrery,p,[.15,i*.4,0]);}
  for(const x of [-1.95,1.95]){rod([x,1.9,0],[x,4,0],.09,mats.orange,base);cylinder(.24,.24,.3,mats.metal,base,[x,4,0],[0,0,Math.PI/2]);}
  // Light-catching crescent drawn on the lens.
  const c=new THREE.EllipseCurve(0,0,1.35,1.35,.4,1.3,false,0);const gp=new THREE.BufferGeometry().setFromPoints(c.getPoints(32));resources.add(gp);const lm=new THREE.LineBasicMaterial({color:paper,transparent:true,opacity:.7});resources.add(lm);const highlight=new THREE.Line(gp,lm);highlight.position.z=.06;lens.add(highlight);
}
function makeArchitecture(world){
  // Structural arches, bolts and feet belong to one workshop floor, not three cards.
  const arch=new THREE.Shape();arch.moveTo(-5.4,0);arch.lineTo(-5.4,4);arch.quadraticCurveTo(-5.4,7.3,-2,7.3);arch.lineTo(4.8,7.3);arch.lineTo(4.8,6.95);arch.lineTo(-2,6.95);arch.quadraticCurveTo(-5.05,6.95,-5.05,4);arch.lineTo(-5.05,0);arch.closePath();
  mesh(new THREE.ExtrudeGeometry(arch,{depth:.23,bevelEnabled:true,bevelSegments:1,steps:1,bevelSize:.035,bevelThickness:.035}),mats.orange,world,[.3,0,-3.1]);
  rod([5.1,0,-3],[5.1,7.1,-3],.085,mats.orange,world);
  for(let i=0;i<9;i++)sphere(.055,mats.metal,world,[-1.8+i*.75,7.12,-2.8]);
  for(let i=0;i<3;i++){
    const x=-3+i*3.4;rod([x,7.05,-2.8],[x,5.85-i*.6,-2.8],.022,mats.dark,world);
    ring(.19,.045,mats.orange,world,[x,5.7-i*.6,-2.8]);
  }
  gear(.95,15,world,[-2.1,.9,-2.0],mats.teal);gear(.6,12,world,[-.8,.7,-2.05],mats.orange);
  const floor=cylinder(8.2,8.2,.12,mats.floor,world,[0,-.2,0],undefined,100);floor.scale.z=.64;floor.castShadow=false;
  for(let i=0;i<15;i++){const x=-7+i;rod([x,-.13,-3],[x,-.13,3],.009,mats.grid,world);}
  for(let i=0;i<7;i++)rod([-7,-.13,-3+i],[7,-.13,-3+i],.009,mats.grid,world);
  for(const x of [-6.2,5.8])box(.85,.13,.8,mats.dark,world,[x,-.07,-1]);
}
function updatePaper(){
  const {columns,rows}=dynamic.paperSize,attr=dynamic.sheet.geometry.attributes.position;
  for(let i=0;i<=columns;i++)for(let j=0;j<=rows;j++)attr.setXYZ(i*(rows+1)+j,...paperPoint(i/columns,(j/rows-.5)*2,mode==='press'?progress:modeProgress.press));
  attr.needsUpdate=true;dynamic.sheet.geometry.computeVertexNormals();dynamic.sheet.geometry.computeBoundingSphere();
  dynamic.paperEdges.forEach((line,k)=>{const a=line.geometry.attributes.position;for(let i=0;i<=columns;i++)a.setXYZ(i,...paperPoint(i/columns,k?1:-1,mode==='press'?progress:modeProgress.press));a.needsUpdate=true;line.geometry.computeBoundingSphere();});
}
function updateDrawing(){
  const lift=mode==='draw'?progress:modeProgress.draw;
  dynamic.steps.forEach((step,i)=>{const p=drawingPoint(i,lift);step.position.set(...p);const strut=dynamic.struts[i];strut.position.set(p[0],p[1]/2,p[2]);strut.scale.y=Math.max(.02,p[1]);});
  dynamic.spine.scale.y=Math.max(.03,lift);
  const p=drawingPoint(12,lift);dynamic.pencil.position.set(p[0]+.1,p[1]+3.2,p[2]+1);dynamic.pencil.rotation.z=-.25+lift*.12;
}
function updateCamera(dt,snap){
  const mobile=stage.clientWidth<820;
  const positions={press:[12.7,10.5,19.5],draw:[10.2,9.8,18.7],inspect:[10.5,9.3,19.4]};
  const targets={press:[-.55,3.15,0],draw:[.1,3.45,.1],inspect:[1.1,3.55,-.1]};
  targetCamera.set(...positions[mode]);targetCamera.multiplyScalar(mobile?1.13:1);targetCamera.x+=(progress-.5)*.6+(reduced?0:pointer.x*.35);targetCamera.y+=(reduced?0:pointer.y*.18);
  targetLook.set(...targets[mode]);
  if(snap){camera.position.copy(targetCamera);look.copy(targetLook);}else{const a=1-Math.exp(-dt*4.4);camera.position.lerp(targetCamera,a);look.lerp(targetLook,a);}
  camera.lookAt(look);cameraSettled=camera.position.distanceTo(targetCamera)<.004&&look.distanceTo(targetLook)<.004;
}
let previousProgress=-1,previousMode='';
function frame(ms){
  raf=0;if(!active||document.hidden||!renderer||!alive)return;
  const dt=Math.min(.045,last?(ms-last)/1000:.016);last=ms;
  if(!paused&&!reduced)elapsed+=dt;
  const snap=paused||reduced;
  progress=snap?targetProgress:THREE.MathUtils.damp(progress,targetProgress,6,dt);
  if(Math.abs(progress-targetProgress)<.0001)progress=targetProgress;
  if(previousProgress!==progress||previousMode!==mode){updatePaper();updateDrawing();previousProgress=progress;previousMode=mode;}
  const canAnimate=!paused&&!reduced;
  handles.forEach((g,i)=>{g.rotation.z=canAnimate?elapsed*(i%2?-.12:.09):g.rotation.z;});
  const stampAge=elapsed-stampAt,down=canAnimate&&stampAge<.9?Math.sin(Math.min(1,stampAge/.9)*Math.PI):0;
  dynamic.stamp.position.y=1.7-down*.7;dynamic.lever.rotation.x=-down*.65;
  dynamic.lens.rotation.y=(mode==='inspect'?(progress-.5)*1.2:0)+(canAnimate?Math.sin(elapsed*.21)*.035:0);
  dynamic.orrery.rotation.z=canAnimate?elapsed*.065:dynamic.orrery.rotation.z;
  dynamic.nodes.forEach((node,i)=>{node.material=i===inspection?mats.orange:mats.cream;node.scale.setScalar(i===inspection?1.32:1);});
  updateCamera(dt,snap);
  try{renderer.render(scene,camera);}catch(error){fail('3D unavailable. Showing the art-direction fallback.');console.warn('Studio renderer stopped:',error.message);return;}
  if(canAnimate||!cameraSettled||progress!==targetProgress)requestRender();
}
function resize(){if(!renderer)return;const w=stage.clientWidth,h=stage.clientHeight;renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.6));renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();cameraSettled=false;requestRender();}
function fail(message){alive=false;cancelAnimationFrame(raf);raf=0;stage.classList.remove('gpu-ready');stage.classList.add('failed');$('#renderer-state').textContent=message;$('#pause').hidden=true;announce(message+' The demonstration controls and app links remain available.');}
try{
  renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:true,powerPreference:'high-performance'});
  renderer.setClearColor(ink,0);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.35;renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
  scene=new THREE.Scene();scene.fog=new THREE.Fog(ink,33,58);camera=new THREE.PerspectiveCamera(36,1,.1,100);camera.zoom=1.15;camera.position.set(13,10,20);
  mats.orange=material(orange,{roughness:.4,metalness:.3});mats.cream=material(paper,{roughness:.82,metalness:0});mats.paper=material(paper,{roughness:1,metalness:0,side:THREE.DoubleSide});mats.dark=material(0x102a35,{metalness:.55,roughness:.37});mats.metal=material(0x9daaa5,{metalness:.72,roughness:.3});mats.teal=material(0x4f9692,{metalness:.4});mats.wood=material(0xc69d68,{roughness:.9});mats.glass=material(0x7db6ac,{transparent:true,opacity:.1,roughness:.13,metalness:.1,side:THREE.DoubleSide,depthWrite:false});mats.floor=material(0x13252e,{roughness:1});mats.grid=material(0x2b3e44,{roughness:1});
  scene.add(new THREE.HemisphereLight(0xffebc6,0x486c82,2.2));
  const key=new THREE.DirectionalLight(0xffecd1,4.1);key.position.set(-6,12,8);key.castShadow=true;key.shadow.mapSize.set(2048,2048);key.shadow.camera.left=-12;key.shadow.camera.right=12;key.shadow.camera.top=12;key.shadow.camera.bottom=-9;key.shadow.normalBias=.035;key.shadow.bias=-.0002;scene.add(key);
  const rim=new THREE.DirectionalLight(0x8bcbd5,2.1);rim.position.set(6,7,-5);scene.add(rim);
  const fill=new THREE.DirectionalLight(0xfc8f4e,.8);fill.position.set(-7,3,0);scene.add(fill);
  const world=new THREE.Group();world.rotation.y=-.16;scene.add(world);
  makeArchitecture(world);makePress(world);makePaper(world);makeDrawing(world);makeLens(world);
  resize();updatePaper();updateDrawing();updateCamera(.016,true);renderer.render(scene,camera);
  stage.classList.add('gpu-ready');$('#renderer-state').textContent='Live 3D · Drag the controls below';
  new ResizeObserver(resize).observe(stage);
  new IntersectionObserver(entries=>{active=entries[0].isIntersecting;if(!active){cancelAnimationFrame(raf);raf=0;last=0;}else requestRender();},{threshold:0}).observe(stage);
  document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(raf);raf=0;last=0;}else requestRender();});
  stage.addEventListener('pointermove',event=>{if(reduced||paused||event.pointerType==='touch')return;const rect=stage.getBoundingClientRect();pointer.x=(event.clientX-rect.left)/rect.width-.5;pointer.y=(event.clientY-rect.top)/rect.height-.5;cameraSettled=false;requestRender();});
  stage.addEventListener('pointerleave',()=>{pointer={x:0,y:0};requestRender();});
  canvas.addEventListener('webglcontextlost',event=>{event.preventDefault();fail('3D paused by the browser. Showing the static view.');});
  requestRender();
}catch(error){fail('Static art-direction view · 3D not available');console.warn('Studio initialization:',error.message);}
window.addEventListener('pagehide',event=>{
  cancelAnimationFrame(raf);raf=0;last=0;
  if(event.persisted)return; // Preserve WebGL resources for back-forward cache restoration.
  alive=false;resources.forEach(resource=>resource.dispose());renderer?.dispose();
});
window.addEventListener('pageshow',event=>{if(event.persisted&&alive){last=0;cameraSettled=false;requestRender();}});
