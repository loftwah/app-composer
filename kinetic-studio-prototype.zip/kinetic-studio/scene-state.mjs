export const clamp01 = value => Math.max(0, Math.min(1, Number.isFinite(value) ? value : 0));
export function paperPoint(t, across, progress) {
  const p = clamp01(progress);
  const curl = Math.sin(t * Math.PI * 1.55 - p * .7);
  return [
    -6.2 + t * 10.1,
    .95 + Math.sin(t * Math.PI) * (1.2 + p * 2.5) + Math.max(0, t - .55) ** 2 * (7 + p * 5),
    .5 + curl * (1.0 + p * .75) + across * 1.25,
  ];
}
export function drawingPoint(index, progress) {
  const p = clamp01(progress), t = index / 12;
  const angle = t * Math.PI * 1.55;
  return [Math.cos(angle) * (1.3 - t * .25), .12 + t * 4.4 * p, Math.sin(angle) * 1.3];
}
export function modeCopy(mode) {
  return ({press:{name:'Paperwork',context:'Fill PDF forms with files that stay in your browser.',href:'https://composer.loftwah.com/paperwork',label:'Pull the paper',action:'Stamp the page',instruction:'Pull the paper, then make your mark.',caption:'Give the paper a little purpose.',readout:'Pull a sheet through the press. Stamp a fictional page.'},draw:{name:'LDraw',context:'LDraw is an independent drawing app.',href:'https://composer.loftwah.com/ldraw',label:'Lift the drawing',action:'Build the drawing',instruction:'Take a line into another dimension.',caption:'A drawing with somewhere to go.',readout:'Lift a flat drawing into a three-dimensional structure.'},inspect:{name:'Analytics',context:'Composer reporting counts recorded requests and supported actions, not people.',href:'https://composer.loftwah.com/activity',label:'Turn the lens',action:'Inspect a connection',instruction:'Look closer. Follow a connection.',caption:'Make room for a closer look.',readout:'Explore a fictional evidence instrument. These are not live analytics.'}})[mode] || null;
}
